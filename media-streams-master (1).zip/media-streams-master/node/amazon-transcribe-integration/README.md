# Amazon Transcribe Integration

Live Sample application [Talkin' Cedric](https://talkin-cedric.glitch.me)

Check out the code [Talkin' Cedric on GitHub](https://github.com/TwilioDevEd/talkin-cedric)